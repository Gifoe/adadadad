---
license: cc-by-4.0
task_categories:
  - other
tags:
  - EEG
  - neuroscience
  - benchmark
---

# demo_dataset (alternate split seed=20260726)

Processed EEG demo package matching the layout of `USuCgex0122e/demo_dataset`,
with subject-disjoint split seed **20260726** (primary release uses `20260725`).

Large datasets are **sparsely subsampled** to approximate original demo sizes.

Per dataset: `train.h5` / `val.h5` / `test.h5` (`X`, `y`) + Croissant metadata.

## Included datasets

- `AD65` — subjects=88, splits={'train': 4594, 'val': 1229, 'test': 1190}, sparse=False
- `BCIC2A` — subjects=9, splits={'train': 2098, 'val': 1091, 'test': 1507}, sparse=False
- `CHB_MIT` — subjects=24, splits={'train': 1520, 'val': 25338, 'test': 23407}, sparse=True
- `CIRE` — subjects=18, splits={'train': 1105, 'val': 190, 'test': 237}, sparse=False
- `DEAP` — subjects=32, splits={'train': 5520, 'val': 1920, 'test': 240}, sparse=False
- `EEGMAT` — subjects=36, splits={'train': 661, 'val': 96, 'test': 96}, sparse=False
- `EEG_SVRec` — subjects=27, splits={'train': 44797, 'val': 3981, 'test': 25106}, sparse=False
- `ISRUC_S1` — subjects=100, splits={'train': 9125, 'val': 5237, 'test': 4598}, sparse=True
- `MDD` — subjects=62, splits={'train': 4594, 'val': 1234, 'test': 695}, sparse=False
- `MODMA` — subjects=53, splits={'train': 557, 'val': 76, 'test': 165}, sparse=False
- `MusicEEG` — subjects=31, splits={'train': 9280, 'val': 2608, 'test': 3968}, sparse=False
- `Physionet_MI` — subjects=109, splits={'train': 6483, 'val': 1440, 'test': 1914}, sparse=False
- `SEED_V` — subjects=16, splits={'train': 629, 'val': 3564, 'test': 1782}, sparse=True
- `SEED_VIG` — subjects=21, splits={'train': 14160, 'val': 4425, 'test': 1770}, sparse=False
- `SEED_VII` — subjects=20, splits={'train': 4480, 'val': 2734, 'test': 2734}, sparse=True
- `SHU_MI` — subjects=25, splits={'train': 8074, 'val': 1873, 'test': 1252}, sparse=False
- `Siena_EEG` — subjects=14, splits={'train': 844, 'val': 1804, 'test': 3157}, sparse=True
- `SleepEDF` — subjects=100, splits={'train': 22790, 'val': 40989, 'test': 43334}, sparse=True
- `TUAB` — subjects=2329, splits={'train': 10400, 'val': 4967, 'test': 5277}, sparse=True
- `TUEV` — subjects=291, splits={'train': 8370, 'val': 2496, 'test': 1684}, sparse=False
- `TUSL` — subjects=38, splits={'train': 231, 'val': 21, 'test': 48}, sparse=False
- `TUSZ` — subjects=74, splits={'train': 3000, 'val': 1000, 'test': 1000}, sparse=True
- `Things_EEG2` — subjects=10, splits={'train': 640, 'val': 2000, 'test': 2000}, sparse=True
- `Workload` — subjects=12, splits={'train': 7632, 'val': 2862, 'test': 954}, sparse=False
