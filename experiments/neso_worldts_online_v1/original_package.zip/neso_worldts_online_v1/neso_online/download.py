"""Download official NESO CKAN resources with streaming, retry, SHA256 logging.

Archives are very large. Use `--resources forecast_2025 demand_2025 ...` to
obtain official full-year CSVs. Data redistribution is avoided; files stay local.
"""
from __future__ import annotations
import argparse,hashlib,json,time
from pathlib import Path
from urllib.parse import quote
import requests

# Resource IDs are taken from the official NESO resource documentation.
RESOURCES={
 'forecast_2025':'fc13df13-2dad-4a1c-b9e3-4569efba4955',
 'forecast_2026_jan_jun':'d6375700-69c2-4c25-8bde-883a205d742e',
 'forecast_2026_jun_dec':'31861619-0b86-47ba-bac2-d008a760af54',
 'demand_2025':'b2bde559-3455-4021-b179-dfe60c0337b0',
 'demand_2026':'8a4a771c-3929-4e56-93ad-cdf13219dea5',
}


def fetch(name,outdir,session=None,chunk_mb=2):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    if name not in RESOURCES:raise ValueError(f'Unknown resource {name}')
    rid=RESOURCES[name]
    url=f'https://api.neso.energy/datastore/dump/{rid}?format=csv'
    filename=outdir/f'{name}.csv'
    sess=session or requests.Session()
    if filename.exists() and filename.stat().st_size>100:
        print(f'{filename} already exists; verify against your saved SHA256 manifest before trusting')
        return filename
    part=filename.with_suffix('.csv.part')
    for attempt in range(4):
        try:
            with sess.get(url,stream=True,timeout=(20,120),headers={'User-Agent':'NESO-WorldTS-Research/0.1'}) as resp:
                resp.raise_for_status()
                ctype=resp.headers.get('Content-Type','')
                if 'application/json' in ctype.lower():
                    raise ValueError(f'Unexpected JSON instead of CSV: {resp.text[:300]}')
                with part.open('wb') as f:
                    for block in resp.iter_content(chunk_size=chunk_mb*1024*1024):
                        if block:f.write(block)
            with part.open('rb') as f:
                head=f.read(500).decode('utf-8-sig',errors='replace')
            if 'SETTLEMENT' not in head and 'DATE_GMT' not in head:
                raise ValueError(f'Response does not look like NESO CSV: {head[:200]}')
            part.replace(filename)
            h=hashlib.sha256()
            with filename.open('rb') as f:
                for block in iter(lambda:f.read(2**20),b''):
                    h.update(block)
            info={'resource_id':rid,'name':name,'source_url':url,'file':str(filename),
                  'size_bytes':filename.stat().st_size,'sha256':h.hexdigest()}
            filename.with_suffix('.metadata.json').write_text(json.dumps(info,indent=2))
            print(json.dumps(info,indent=2));return filename
        except Exception as e:
            print(f'{name}: attempt={attempt+1} error={e}')
            if attempt==3:raise
            time.sleep(2**attempt)
    raise RuntimeError('unreachable')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--resources',nargs='+',choices=list(RESOURCES),default=list(RESOURCES))
    ap.add_argument('--out',default='data/raw')
    a=ap.parse_args()
    for n in a.resources:fetch(n,a.out)

if __name__=='__main__':main()
